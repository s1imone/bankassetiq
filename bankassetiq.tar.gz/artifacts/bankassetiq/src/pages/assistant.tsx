import { useState, useRef, useEffect } from "react";
import { Bot, Send, User, Sparkles } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface Message {
  id: number;
  sender: 'user' | 'bot';
  text: string;
}

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, sender: 'bot', text: "Hello! I'm AssetBot, your BankAssetIQ assistant. How can I help you manage the bank's inventory today?" }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    "How do I assign an asset?",
    "What does LOST status mean?",
    "How do I mark an asset as repaired?",
    "How do I view asset history?",
    "What is BankAssetIQ?"
  ];

  const botResponses: Record<string, string> = {
    "How do I assign an asset?": "To assign an asset, go to the Assets list, click the View Details (eye icon) on the asset you want, and click the 'Assign' button at the top. Fill in the employee or department details and submit.",
    "What does LOST status mean?": "LOST status indicates the asset cannot be located during an audit or was reported missing by an employee. Assets marked LOST cannot be reassigned until they are found and their status is changed.",
    "How do I mark an asset as repaired?": "Navigate to the asset's detail page (the asset must currently be IN_REPAIR). Click the green 'Mark Repaired' button to return its status to REGISTERED, making it available for assignment.",
    "How do I view asset history?": "Every asset has a detailed 'Lifecycle History' timeline on its detail page. It logs every status change, assignment, return, and comment with timestamps and user records.",
    "What is BankAssetIQ?": "BankAssetIQ is our modern enterprise banking asset management platform. It tracks IT, Office, Security, and Infrastructure assets across all our branches ensuring compliance, accountability, and smooth operations."
  };

  const handleSend = (text: string = input) => {
    if (!text.trim()) return;
    
    const userMsg = { id: Date.now(), sender: 'user' as const, text };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsTyping(true);

    // Simulate bot thinking
    setTimeout(() => {
      let botText = "I'm a prototype assistant! While I can't answer everything right now, I'm here to help showcase the BankAssetIQ experience.";
      
      // Match predefined questions
      const matchedKey = Object.keys(botResponses).find(k => text.toLowerCase().includes(k.toLowerCase().replace("?", "")));
      if (matchedKey) botText = botResponses[matchedKey];

      setMessages(prev => [...prev, { id: Date.now()+1, sender: 'bot', text: botText }]);
      setIsTyping(false);
    }, 1000);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col md:flex-row gap-6">
      <div className="w-full md:w-80 flex-shrink-0 space-y-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground flex items-center">
            <Bot className="w-6 h-6 mr-2 text-primary" />
            Asset Assistant
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">Ask questions about bank assets, operations, or how to use the platform.</p>
        </div>
        
        <div className="space-y-2 mt-6">
          <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3">Suggested Topics</h3>
          {quickQuestions.map((q, i) => (
            <Button 
              key={i} 
              variant="outline" 
              className="w-full justify-start text-left h-auto whitespace-normal p-3 hover:bg-primary/5 hover:text-primary hover:border-primary/30 shadow-sm"
              onClick={() => handleSend(q)}
            >
              <Sparkles className="w-4 h-4 mr-2 flex-shrink-0 text-primary/50" />
              <span className="text-sm">{q}</span>
            </Button>
          ))}
        </div>
      </div>

      <Card className="flex-1 flex flex-col shadow-lg border-border/60 overflow-hidden">
        <div className="p-4 border-b bg-card flex items-center shadow-sm z-10">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
            <Bot className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="font-bold text-foreground">AssetBot</h2>
            <div className="flex items-center text-xs text-muted-foreground">
              <span className="w-2 h-2 rounded-full bg-green-500 mr-1.5"></span>
              Online and ready to help
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50/50" ref={scrollRef}>
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`flex max-w-[80%] ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${msg.sender === 'user' ? 'bg-primary text-primary-foreground ml-3' : 'bg-primary/10 text-primary mr-3'}`}>
                  {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>
                <div className={`p-4 rounded-2xl text-sm ${
                  msg.sender === 'user' 
                    ? 'bg-primary text-primary-foreground rounded-tr-none shadow-md shadow-primary/20' 
                    : 'bg-card border border-border shadow-sm rounded-tl-none text-foreground leading-relaxed'
                }`}>
                  {msg.text}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex flex-row">
                <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-primary/10 text-primary mr-3">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="p-4 rounded-2xl rounded-tl-none bg-card border border-border shadow-sm flex space-x-2 items-center">
                  <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce"></div>
                  <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{animationDelay: "0.2s"}}></div>
                  <div className="w-2 h-2 rounded-full bg-primary/40 animate-bounce" style={{animationDelay: "0.4s"}}></div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-card border-t z-10">
          <form 
            className="flex items-center gap-2"
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          >
            <Input 
              placeholder="Ask anything about assets..." 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-background"
            />
            <Button type="submit" size="icon" disabled={!input.trim() || isTyping}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </Card>
    </div>
  );
}
