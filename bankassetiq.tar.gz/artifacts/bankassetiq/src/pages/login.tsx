import { useState } from "react";
import { useLocation } from "wouter";
import { Banknote, ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Login() {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState("admin@bank.com");
  const [password, setPassword] = useState("password");
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate network delay
    setTimeout(() => {
      localStorage.setItem("auth_user", JSON.stringify({
        name: "Admin User",
        email: email,
        role: "System Administrator"
      }));
      setLocation("/dashboard");
    }, 800);
  };

  return (
    <div className="min-h-screen w-full flex bg-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/auth-bg.png`} 
          alt="Auth background" 
          className="w-full h-full object-cover opacity-90"
        />
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm lg:bg-background/40"></div>
      </div>

      <div className="w-full max-w-md mx-auto flex items-center justify-center p-4 z-10 lg:ml-[10%]">
        <Card className="w-full shadow-2xl shadow-primary/10 border-border/50 bg-card/95 backdrop-blur-xl">
          <CardHeader className="space-y-3 pb-6">
            <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-primary/10 text-primary mb-2 mx-auto">
              <Banknote className="w-6 h-6" />
            </div>
            <CardTitle className="text-2xl font-display text-center font-bold">Welcome to BankAssetIQ</CardTitle>
            <CardDescription className="text-center text-muted-foreground">
              Enterprise Asset Management Platform
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">Work Email</Label>
                <Input 
                  id="email" 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@bank.com" 
                  required 
                  className="bg-background/50 h-11"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <a href="#" className="text-xs text-primary font-medium hover:underline">Forgot password?</a>
                </div>
                <Input 
                  id="password" 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required 
                  className="bg-background/50 h-11"
                />
              </div>
              
              <Button type="submit" className="w-full h-11 text-base group" disabled={loading}>
                {loading ? "Authenticating..." : "Sign In"}
                {!loading && <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />}
              </Button>

              <div className="flex items-center justify-center space-x-2 text-xs text-muted-foreground pt-4">
                <ShieldCheck className="w-4 h-4 text-green-600" />
                <span>Secure Bank Authentication Gateway</span>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
