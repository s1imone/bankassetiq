import { useState } from "react";
import { Link } from "wouter";
import { Plus, Search, Filter, MoreHorizontal, Eye } from "lucide-react";
import { useForm } from "react-form";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useAssets, useCreateAsset } from "@/hooks/use-assets";
import { DEPARTMENTS, BRANCHES } from "@/lib/mock-data";
import { formatDate } from "@/lib/utils";

export default function AssetsList() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [categoryFilter, setCategoryFilter] = useState("ALL");
  
  const { data: assets, isLoading } = useAssets({ search, status: statusFilter, category: categoryFilter });
  const createAsset = useCreateAsset();

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [formData, setFormData] = useState({
    assetName: "", assetType: "", category: "", serialNumber: "", description: "", branch: "", department: "", purchaseDate: ""
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAsset.mutate({
      ...formData,
      status: "REGISTERED",
    }, {
      onSuccess: () => {
        setIsAddOpen(false);
        setFormData({assetName: "", assetType: "", category: "", serialNumber: "", description: "", branch: "", department: "", purchaseDate: ""});
      }
    });
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'REGISTERED': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'ASSIGNED': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'IN_REPAIR': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'LOST': return 'bg-red-100 text-red-700 border-red-200';
      case 'WRITTEN_OFF': return 'bg-slate-800 text-slate-100 border-slate-700';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6 pb-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">Asset Inventory</h1>
          <p className="text-muted-foreground mt-1">Manage all banking hardware and software assets.</p>
        </div>
        
        <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
          <DialogTrigger asChild>
            <Button className="shadow-md shadow-primary/20">
              <Plus className="w-4 h-4 mr-2" />
              Add New Asset
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Register New Asset</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubmit} className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Asset Name *</Label>
                  <Input required value={formData.assetName} onChange={e => setFormData({...formData, assetName: e.target.value})} placeholder="e.g. Dell Latitude 5440" />
                </div>
                <div className="space-y-2">
                  <Label>Serial Number *</Label>
                  <Input required value={formData.serialNumber} onChange={e => setFormData({...formData, serialNumber: e.target.value})} placeholder="e.g. DL-12345" />
                </div>
                <div className="space-y-2">
                  <Label>Category *</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({...formData, category: v})}>
                    <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>
                      {["IT", "Office", "Security", "Networking", "Infrastructure"].map(c => (
                        <SelectItem key={c} value={c}>{c}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Asset Type</Label>
                  <Input required value={formData.assetType} onChange={e => setFormData({...formData, assetType: e.target.value})} placeholder="e.g. Laptop, Switch" />
                </div>
                <div className="space-y-2">
                  <Label>Department</Label>
                  <Select value={formData.department} onValueChange={v => setFormData({...formData, department: v})}>
                    <SelectTrigger><SelectValue placeholder="Select dept" /></SelectTrigger>
                    <SelectContent>
                      {DEPARTMENTS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Branch</Label>
                  <Select value={formData.branch} onValueChange={v => setFormData({...formData, branch: v})}>
                    <SelectTrigger><SelectValue placeholder="Select branch" /></SelectTrigger>
                    <SelectContent>
                      {BRANCHES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 col-span-2">
                  <Label>Purchase Date</Label>
                  <Input type="date" value={formData.purchaseDate} onChange={e => setFormData({...formData, purchaseDate: e.target.value})} />
                </div>
              </div>
              <div className="flex justify-end pt-4 space-x-2 border-t">
                <Button variant="outline" type="button" onClick={() => setIsAddOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={createAsset.isPending}>
                  {createAsset.isPending ? "Saving..." : "Save Asset"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-border shadow-sm">
        <div className="p-4 border-b border-border flex flex-col md:flex-row gap-4 items-center justify-between bg-muted/30">
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
            <Input 
              placeholder="Search by name or serial..." 
              className="pl-9 bg-background"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="flex w-full md:w-auto gap-3">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-full md:w-40 bg-background">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Categories</SelectItem>
                <SelectItem value="IT">IT</SelectItem>
                <SelectItem value="Office">Office</SelectItem>
                <SelectItem value="Security">Security</SelectItem>
                <SelectItem value="Networking">Networking</SelectItem>
                <SelectItem value="Infrastructure">Infrastructure</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40 bg-background">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="REGISTERED">Registered</SelectItem>
                <SelectItem value="ASSIGNED">Assigned</SelectItem>
                <SelectItem value="IN_REPAIR">In Repair</SelectItem>
                <SelectItem value="LOST">Lost</SelectItem>
                <SelectItem value="WRITTEN_OFF">Written Off</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-muted-foreground bg-muted/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 font-medium">Asset Details</th>
                <th className="px-6 py-4 font-medium">Serial Number</th>
                <th className="px-6 py-4 font-medium">Status</th>
                <th className="px-6 py-4 font-medium">Owner / Location</th>
                <th className="px-6 py-4 font-medium">Purchase Date</th>
                <th className="px-6 py-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground animate-pulse">Loading assets...</td>
                </tr>
              ) : assets?.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-muted-foreground">No assets found matching your filters.</td>
                </tr>
              ) : (
                assets?.map((asset) => (
                  <tr key={asset.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-semibold text-foreground">{asset.assetName}</div>
                      <div className="text-xs text-muted-foreground">{asset.category} • {asset.assetType}</div>
                    </td>
                    <td className="px-6 py-4 font-mono text-xs">{asset.serialNumber}</td>
                    <td className="px-6 py-4">
                      <Badge className={`border uppercase text-[10px] font-bold ${getStatusColor(asset.status)}`} variant="outline">
                        {asset.status.replace("_", " ")}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium">{asset.ownerName || <span className="text-muted-foreground italic">Unassigned</span>}</div>
                      <div className="text-xs text-muted-foreground">{asset.branch || '-'}</div>
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      {asset.purchaseDate ? formatDate(asset.purchaseDate) : '-'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <Link href={`/assets/${asset.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
