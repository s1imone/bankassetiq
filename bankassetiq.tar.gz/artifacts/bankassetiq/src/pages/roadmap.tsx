import { Map, Rocket, ArrowRight, Server, Search, Smartphone, BarChart3, Fingerprint } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Roadmap() {
  const items = [
    {
      title: "Real AI Recommendations",
      description: "Machine-learning powered lifecycle predictions that analyze repair history and age to recommend when to write off assets before they fail.",
      status: "In Progress",
      icon: Rocket,
      color: "blue"
    },
    {
      title: "Mobile App",
      description: "Native iOS and Android app for branch managers to scan QR codes and update asset statuses directly from their phones.",
      status: "Next",
      icon: Smartphone,
      color: "green"
    },
    {
      title: "Enhanced Secure Login",
      description: "Implementing bank-grade MFA, SSO integration, and biometric authentication for system administrators.",
      status: "Planned",
      icon: Fingerprint,
      color: "gray"
    },
    {
      title: "Enterprise Integrations",
      description: "Direct syncing with SAP, ServiceNow, LDAP, and Active Directory to eliminate duplicate data entry.",
      status: "Planned",
      icon: Server,
      color: "gray"
    },
    {
      title: "Advanced Audit Engine",
      description: "Automated compliance reports and randomized audit scheduling for security and infrastructure assets.",
      status: "Planned",
      icon: Search,
      color: "gray"
    },
    {
      title: "Advanced Analytics",
      description: "Drill-down financial dashboards forecasting future hardware expenditures based on historical write-off data.",
      status: "Planned",
      icon: BarChart3,
      color: "gray"
    }
  ];

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'In Progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'Next': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-600 border-gray-200';
    }
  };

  return (
    <div className="space-y-8 pb-10">
      <div className="bg-primary/5 border border-primary/10 rounded-2xl p-8 md:p-12 text-center max-w-4xl mx-auto shadow-sm">
        <div className="w-16 h-16 bg-primary text-primary-foreground rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-primary/20">
          <Map className="w-8 h-8" />
        </div>
        <h1 className="text-4xl font-display font-extrabold text-foreground tracking-tight mb-4">Roadmap 2.0</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          We are constantly evolving BankAssetIQ to meet the rigorous demands of modern banking infrastructure. Here's a look at what's coming next.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
        {items.map((item, index) => (
          <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border/50 bg-card overflow-hidden group">
            <div className={`h-1.5 w-full bg-${item.color}-500 opacity-80`} />
            <CardHeader className="pb-4">
              <div className="flex justify-between items-start mb-2">
                <div className={`p-2.5 rounded-xl bg-${item.color}-100/50 text-${item.color}-600 group-hover:bg-${item.color}-100 transition-colors`}>
                  <item.icon className="w-5 h-5" />
                </div>
                <Badge variant="outline" className={`font-semibold ${getStatusColor(item.status)}`}>
                  {item.status}
                </Badge>
              </div>
              <CardTitle className="text-xl">{item.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-sm text-foreground/70 leading-relaxed">
                {item.description}
              </CardDescription>
              <div className="mt-6 flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                Read specifications <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
