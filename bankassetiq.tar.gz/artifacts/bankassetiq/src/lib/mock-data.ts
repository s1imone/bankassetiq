import { create } from 'zustand';
import type { Asset, AssetHistory, DashboardStats } from '@shared/schema';

// We import types locally to avoid resolving issues if they are missing
export type AssetStatus = "REGISTERED" | "ASSIGNED" | "IN_REPAIR" | "LOST" | "WRITTEN_OFF";
export type AssetCategory = "IT" | "Office" | "Security" | "Networking" | "Infrastructure";
export type OwnerType = "Employee" | "Department" | "Branch";

export interface MockAsset {
  id: number;
  assetName: string;
  assetType: string;
  category: AssetCategory;
  serialNumber: string;
  description?: string;
  status: AssetStatus;
  ownerName?: string | null;
  ownerType?: OwnerType | null;
  assignedBy?: string | null;
  assignedDate?: string | null;
  department?: string | null;
  branch?: string | null;
  purchaseDate?: string | null;
  imageUrl?: string | null;
  createdAt: string;
  updatedAt: string;
  ageDays?: number | null;
}

export interface MockAssetHistory {
  id: number;
  assetId: number;
  action: string;
  oldValue?: string | null;
  newValue?: string | null;
  changedBy: string;
  reason?: string | null;
  createdAt: string;
}

const initialAssets: MockAsset[] = [
  {
    id: 1, assetName: "Dell Latitude 5440", assetType: "Laptop", category: "IT", serialNumber: "DL-5440-001",
    status: "ASSIGNED", ownerName: "John Smith", ownerType: "Employee", assignedBy: "Admin", department: "IT Dept", branch: "Tashkent Main Branch",
    purchaseDate: "2023-01-15", createdAt: "2023-01-15T10:00:00Z", updatedAt: "2023-01-16T10:00:00Z", ageDays: 340
  },
  {
    id: 2, assetName: "HP LaserJet Pro M404dn", assetType: "Printer", category: "Office", serialNumber: "HP-LJ-2023-002",
    status: "REGISTERED", department: "Office Operations", branch: "Tashkent Main Branch",
    purchaseDate: "2023-03-10", createdAt: "2023-03-10T10:00:00Z", updatedAt: "2023-03-10T10:00:00Z", ageDays: 290
  },
  {
    id: 3, assetName: "Hikvision DS-2CD2143G2-I", assetType: "CCTV Camera", category: "Security", serialNumber: "HIK-CAM-004",
    status: "ASSIGNED", ownerName: "Security Unit", ownerType: "Department", assignedBy: "Admin", department: "Security Dept", branch: "Tashkent Main Branch",
    purchaseDate: "2022-06-01", createdAt: "2022-06-01T10:00:00Z", updatedAt: "2022-06-01T10:00:00Z", ageDays: 600
  },
  {
    id: 4, assetName: "Cisco Catalyst 2960-X", assetType: "Switch", category: "Networking", serialNumber: "CISCO-2960-007",
    status: "IN_REPAIR", department: "IT Dept", branch: "Mirabad Branch",
    purchaseDate: "2021-11-20", createdAt: "2021-11-20T10:00:00Z", updatedAt: "2023-11-20T10:00:00Z", ageDays: 800
  },
  {
    id: 5, assetName: "Lenovo ThinkVision E24-20", assetType: "Monitor", category: "IT", serialNumber: "LEN-MON-009",
    status: "ASSIGNED", ownerName: "Sarah Johnson", ownerType: "Employee", assignedBy: "Admin", department: "IT Dept", branch: "Mirabad Branch",
    purchaseDate: "2023-05-05", createdAt: "2023-05-05T10:00:00Z", updatedAt: "2023-05-05T10:00:00Z", ageDays: 250
  },
  {
    id: 6, assetName: "APC Smart-UPS 1500VA", assetType: "UPS", category: "Infrastructure", serialNumber: "APC-UPS-012",
    status: "REGISTERED", department: "Branch Operations", branch: "Yunusabad Branch",
    purchaseDate: "2022-09-14", createdAt: "2022-09-14T10:00:00Z", updatedAt: "2022-09-14T10:00:00Z", ageDays: 500
  },
  {
    id: 7, assetName: "ZKTeco SF300 Terminal", assetType: "Access Terminal", category: "Security", serialNumber: "ZK-SF300-015",
    status: "ASSIGNED", ownerName: "Branch Operations", ownerType: "Department", assignedBy: "Admin", department: "Security Dept", branch: "Yunusabad Branch",
    purchaseDate: "2021-07-22", createdAt: "2021-07-22T10:00:00Z", updatedAt: "2021-07-22T10:00:00Z", ageDays: 900
  },
  {
    id: 8, assetName: "NCR 7606 Teller Terminal", assetType: "Teller Terminal", category: "IT", serialNumber: "NCR-7606-018",
    status: "LOST", department: "IT Dept", branch: "Chilanzar Branch",
    purchaseDate: "2020-03-08", createdAt: "2020-03-08T10:00:00Z", updatedAt: "2024-01-08T10:00:00Z", ageDays: 1400
  },
  {
    id: 9, assetName: "Canon imageCLASS MF644Cdw", assetType: "Reception Printer", category: "Office", serialNumber: "CAN-MF644-021",
    status: "ASSIGNED", ownerName: "Sarah Johnson", ownerType: "Employee", assignedBy: "Admin", department: "Office Dept", branch: "Chilanzar Branch",
    purchaseDate: "2023-08-12", createdAt: "2023-08-12T10:00:00Z", updatedAt: "2023-08-12T10:00:00Z", ageDays: 150
  },
  {
    id: 10, assetName: "Dell PowerEdge R540", assetType: "Branch Server", category: "Infrastructure", serialNumber: "DELL-R540-024",
    status: "WRITTEN_OFF", department: "IT Dept", branch: "Tashkent Main Branch",
    purchaseDate: "2019-04-18", createdAt: "2019-04-18T10:00:00Z", updatedAt: "2024-02-18T10:00:00Z", ageDays: 1750
  }
];

let historyIdCounter = 1;
const initialHistory: MockAssetHistory[] = initialAssets.map(a => ({
  id: historyIdCounter++,
  assetId: a.id,
  action: "Asset Registered",
  changedBy: "System Admin",
  createdAt: a.createdAt
}));

interface MockStore {
  assets: MockAsset[];
  history: MockAssetHistory[];
  addAsset: (asset: Omit<MockAsset, "id" | "createdAt" | "updatedAt">) => MockAsset;
  updateAsset: (id: number, updates: Partial<MockAsset>) => MockAsset;
  addHistory: (entry: Omit<MockAssetHistory, "id" | "createdAt">) => MockAssetHistory;
}

export const useMockStore = create<MockStore>((set, get) => ({
  assets: initialAssets,
  history: initialHistory,
  addAsset: (assetData) => {
    const newAsset = {
      ...assetData,
      id: Math.max(...get().assets.map(a => a.id), 0) + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    set(state => ({ assets: [...state.assets, newAsset as MockAsset] }));
    get().addHistory({
      assetId: newAsset.id,
      action: "Asset Registered",
      changedBy: "Current User",
      reason: "Initial entry"
    });
    return newAsset as MockAsset;
  },
  updateAsset: (id, updates) => {
    let updated: MockAsset | undefined;
    set(state => ({
      assets: state.assets.map(a => {
        if (a.id === id) {
          updated = { ...a, ...updates, updatedAt: new Date().toISOString() };
          return updated;
        }
        return a;
      })
    }));
    return updated as MockAsset;
  },
  addHistory: (entry) => {
    const newEntry = {
      ...entry,
      id: historyIdCounter++,
      createdAt: new Date().toISOString(),
    };
    set(state => ({ history: [newEntry, ...state.history] }));
    return newEntry;
  }
}));

export const DEPARTMENTS = ["IT Dept", "Office Operations", "Security Dept", "Branch Operations", "Finance Dept"];
export const BRANCHES = ["Tashkent Main Branch", "Mirabad Branch", "Yunusabad Branch", "Chilanzar Branch", "Sergeli Branch"];
