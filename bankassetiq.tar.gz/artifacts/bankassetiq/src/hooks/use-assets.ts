import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useMockStore, MockAsset, MockAssetHistory } from "@/lib/mock-data";

// Fallback hooks using Zustand store (Acting as our robust mock API)
// In a real app we'd use TanStack fetch queries. Here we use them but intercept to local store.

const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export function useAssets(params?: any) {
  const assets = useMockStore(state => state.assets);
  return useQuery({
    queryKey: ['assets', params],
    queryFn: async () => {
      await delay(400); // Simulate network
      let result = [...assets];
      if (params?.search) {
        const q = params.search.toLowerCase();
        result = result.filter(a => a.assetName.toLowerCase().includes(q) || a.serialNumber.toLowerCase().includes(q));
      }
      if (params?.status && params.status !== "ALL") result = result.filter(a => a.status === params.status);
      if (params?.category && params.category !== "ALL") result = result.filter(a => a.category === params.category);
      if (params?.department && params.department !== "ALL") result = result.filter(a => a.department === params.department);
      if (params?.branch && params.branch !== "ALL") result = result.filter(a => a.branch === params.branch);
      return result;
    }
  });
}

export function useAsset(id: number) {
  const assets = useMockStore(state => state.assets);
  return useQuery({
    queryKey: ['assets', id],
    queryFn: async () => {
      await delay(300);
      const asset = assets.find(a => a.id === id);
      if (!asset) throw new Error("Asset not found");
      return asset;
    },
    enabled: !!id
  });
}

export function useAssetHistory(id: number) {
  const history = useMockStore(state => state.history);
  return useQuery({
    queryKey: ['assets', id, 'history'],
    queryFn: async () => {
      await delay(200);
      return history.filter(h => h.assetId === id).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    },
    enabled: !!id
  });
}

export function useDashboardStats() {
  const assets = useMockStore(state => state.assets);
  const history = useMockStore(state => state.history);
  return useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: async () => {
      await delay(300);
      const totalAssets = assets.length;
      const assignedAssets = assets.filter(a => a.status === "ASSIGNED").length;
      const inRepair = assets.filter(a => a.status === "IN_REPAIR").length;
      const lost = assets.filter(a => a.status === "LOST").length;
      const writtenOff = assets.filter(a => a.status === "WRITTEN_OFF").length;
      const registered = assets.filter(a => a.status === "REGISTERED").length;
      const agingAssets = assets.filter(a => (a.ageDays || 0) > 1095).length;

      const categoryMap: Record<string, number> = {};
      const statusMap: Record<string, number> = {};
      
      assets.forEach(a => {
        categoryMap[a.category] = (categoryMap[a.category] || 0) + 1;
        statusMap[a.status] = (statusMap[a.status] || 0) + 1;
      });

      return {
        totalAssets, assignedAssets, inRepair, lost, writtenOff, registered, agingAssets,
        byCategory: Object.entries(categoryMap).map(([name, value]) => ({ name, value })),
        byStatus: Object.entries(statusMap).map(([name, value]) => ({ name, value })),
        recentActivity: history.slice(0, 10)
      };
    }
  });
}

// Mutations
export function useCreateAsset() {
  const queryClient = useQueryClient();
  const addAsset = useMockStore(state => state.addAsset);
  
  return useMutation({
    mutationFn: async (data: any) => {
      await delay(500);
      return addAsset(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
    }
  });
}

export function useAssignAsset() {
  const queryClient = useQueryClient();
  const updateAsset = useMockStore(state => state.updateAsset);
  const addHistory = useMockStore(state => state.addHistory);

  return useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      await delay(400);
      const updated = updateAsset(id, {
        status: "ASSIGNED",
        ownerName: data.ownerName,
        ownerType: data.ownerType,
        assignedBy: data.assignedBy,
        department: data.department,
        branch: data.branch,
        assignedDate: new Date().toISOString()
      });
      addHistory({
        assetId: id,
        action: "Assigned Asset",
        newValue: `Owner: ${data.ownerName} (${data.department})`,
        changedBy: data.assignedBy,
        reason: data.reason
      });
      return updated;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      queryClient.invalidateQueries({ queryKey: ['assets', variables.id] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
    }
  });
}

export function useChangeAssetStatus() {
  const queryClient = useQueryClient();
  const updateAsset = useMockStore(state => state.updateAsset);
  const addHistory = useMockStore(state => state.addHistory);

  return useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      await delay(400);
      const updated = updateAsset(id, { status: data.status });
      addHistory({
        assetId: id,
        action: `Status changed to ${data.status}`,
        changedBy: data.changedBy,
        reason: data.reason
      });
      return updated;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      queryClient.invalidateQueries({ queryKey: ['assets', variables.id] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
    }
  });
}

export function useReturnAsset() {
  const queryClient = useQueryClient();
  const updateAsset = useMockStore(state => state.updateAsset);
  const addHistory = useMockStore(state => state.addHistory);

  return useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      await delay(400);
      const updated = updateAsset(id, {
        status: "REGISTERED",
        ownerName: null,
        ownerType: null,
        assignedDate: null
      });
      addHistory({
        assetId: id,
        action: "Returned Asset",
        changedBy: data.returnedBy,
        reason: data.reason
      });
      return updated;
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['assets'] });
      queryClient.invalidateQueries({ queryKey: ['assets', variables.id] });
      queryClient.invalidateQueries({ queryKey: ['dashboard-stats'] });
    }
  });
}

export function useAddComment() {
  const queryClient = useQueryClient();
  const addHistory = useMockStore(state => state.addHistory);

  return useMutation({
    mutationFn: async ({ id, data }: { id: number, data: any }) => {
      await delay(300);
      return addHistory({
        assetId: id,
        action: "Comment Added",
        newValue: data.comment,
        changedBy: data.addedBy,
      });
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ['assets', variables.id, 'history'] });
    }
  });
}
