import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { assetsTable, assetHistoryTable, usersTable } from "@workspace/db/schema";
import { eq, and, ilike, or, desc } from "drizzle-orm";
import {
  CreateAssetBody,
  UpdateAssetBody,
  AssignAssetBody,
  ChangeAssetStatusBody,
  ReturnAssetBody,
  AddCommentBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

function calcAgeDays(purchaseDate: string | null | undefined): number | null {
  if (!purchaseDate) return null;
  const d = new Date(purchaseDate);
  if (isNaN(d.getTime())) return null;
  return Math.floor((Date.now() - d.getTime()) / (1000 * 60 * 60 * 24));
}

function assetWithAge(asset: typeof assetsTable.$inferSelect) {
  return {
    ...asset,
    createdAt: asset.createdAt.toISOString(),
    updatedAt: asset.updatedAt.toISOString(),
    ageDays: calcAgeDays(asset.purchaseDate),
  };
}

router.get("/assets", async (req, res) => {
  const { search, status, category, department, branch } = req.query as Record<string, string | undefined>;

  let assets = await db.select().from(assetsTable).orderBy(desc(assetsTable.updatedAt));

  if (search) {
    assets = assets.filter(
      (a) =>
        a.assetName.toLowerCase().includes(search.toLowerCase()) ||
        a.serialNumber.toLowerCase().includes(search.toLowerCase())
    );
  }
  if (status) assets = assets.filter((a) => a.status === status);
  if (category) assets = assets.filter((a) => a.category === category);
  if (department) assets = assets.filter((a) => a.department === department);
  if (branch) assets = assets.filter((a) => a.branch === branch);

  res.json(assets.map(assetWithAge));
});

router.post("/assets", async (req, res) => {
  const body = CreateAssetBody.parse(req.body);
  const [asset] = await db
    .insert(assetsTable)
    .values({
      assetName: body.assetName,
      assetType: body.assetType,
      category: body.category,
      serialNumber: body.serialNumber,
      description: body.description ?? null,
      purchaseDate: body.purchaseDate ?? null,
      branch: body.branch ?? null,
      department: body.department ?? null,
      imageUrl: body.imageUrl ?? null,
      status: "REGISTERED",
    })
    .returning();

  await db.insert(assetHistoryTable).values({
    assetId: asset.id,
    action: "Asset Created",
    oldValue: null,
    newValue: "REGISTERED",
    changedBy: "System",
    reason: "New asset registered",
  });

  res.status(201).json(assetWithAge(asset));
});

router.get("/assets/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const [asset] = await db.select().from(assetsTable).where(eq(assetsTable.id, id));
  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  res.json(assetWithAge(asset));
});

router.put("/assets/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = UpdateAssetBody.parse(req.body);

  const [asset] = await db
    .update(assetsTable)
    .set({
      assetName: body.assetName,
      assetType: body.assetType,
      category: body.category,
      description: body.description,
      branch: body.branch ?? null,
      department: body.department ?? null,
      purchaseDate: body.purchaseDate ?? null,
      imageUrl: body.imageUrl ?? null,
      updatedAt: new Date(),
    })
    .where(eq(assetsTable.id, id))
    .returning();

  if (!asset) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }

  await db.insert(assetHistoryTable).values({
    assetId: id,
    action: "Asset Updated",
    oldValue: null,
    newValue: null,
    changedBy: "Admin",
    reason: "Asset details updated",
  });

  res.json(assetWithAge(asset));
});

router.delete("/assets/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  await db.delete(assetsTable).where(eq(assetsTable.id, id));
  res.status(204).send();
});

router.post("/assets/:id/assign", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = AssignAssetBody.parse(req.body);

  const [existing] = await db.select().from(assetsTable).where(eq(assetsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  if (existing.status === "LOST" || existing.status === "WRITTEN_OFF" || existing.status === "IN_REPAIR") {
    res.status(400).json({ error: `Cannot assign asset with status ${existing.status}` });
    return;
  }

  const [asset] = await db
    .update(assetsTable)
    .set({
      status: "ASSIGNED",
      ownerName: body.ownerName,
      ownerType: body.ownerType,
      assignedBy: body.assignedBy,
      assignedDate: new Date().toISOString().split("T")[0],
      department: body.department ?? existing.department,
      branch: body.branch ?? existing.branch,
      updatedAt: new Date(),
    })
    .where(eq(assetsTable.id, id))
    .returning();

  await db.insert(assetHistoryTable).values({
    assetId: id,
    action: "Asset Assigned",
    oldValue: existing.ownerName ?? "Unassigned",
    newValue: `${body.ownerType}: ${body.ownerName}`,
    changedBy: body.assignedBy,
    reason: body.reason ?? null,
  });

  res.json(assetWithAge(asset));
});

router.post("/assets/:id/status", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = ChangeAssetStatusBody.parse(req.body);

  const [existing] = await db.select().from(assetsTable).where(eq(assetsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  if (existing.status === "WRITTEN_OFF") {
    res.status(400).json({ error: "Cannot change status of a written-off asset" });
    return;
  }

  const [asset] = await db
    .update(assetsTable)
    .set({
      status: body.status,
      updatedAt: new Date(),
    })
    .where(eq(assetsTable.id, id))
    .returning();

  await db.insert(assetHistoryTable).values({
    assetId: id,
    action: `Status Changed to ${body.status}`,
    oldValue: existing.status,
    newValue: body.status,
    changedBy: body.changedBy,
    reason: body.reason ?? null,
  });

  res.json(assetWithAge(asset));
});

router.post("/assets/:id/return", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = ReturnAssetBody.parse(req.body);

  const [existing] = await db.select().from(assetsTable).where(eq(assetsTable.id, id));
  if (!existing) {
    res.status(404).json({ error: "Asset not found" });
    return;
  }
  if (existing.status === "LOST") {
    res.status(400).json({ error: "Cannot return a lost asset" });
    return;
  }

  const prevOwner = existing.ownerName;

  const [asset] = await db
    .update(assetsTable)
    .set({
      status: "REGISTERED",
      ownerName: null,
      ownerType: null,
      assignedBy: null,
      assignedDate: null,
      updatedAt: new Date(),
    })
    .where(eq(assetsTable.id, id))
    .returning();

  await db.insert(assetHistoryTable).values({
    assetId: id,
    action: "Asset Returned",
    oldValue: prevOwner ?? "Unknown",
    newValue: "REGISTERED",
    changedBy: body.returnedBy,
    reason: body.reason ?? null,
  });

  res.json(assetWithAge(asset));
});

router.post("/assets/:id/comments", async (req, res) => {
  const id = parseInt(req.params.id);
  const body = AddCommentBody.parse(req.body);

  const [history] = await db
    .insert(assetHistoryTable)
    .values({
      assetId: id,
      action: "Comment Added",
      oldValue: null,
      newValue: body.comment,
      changedBy: body.addedBy,
      reason: body.comment,
    })
    .returning();

  res.status(201).json({
    ...history,
    createdAt: history.createdAt.toISOString(),
  });
});

router.get("/assets/:id/history", async (req, res) => {
  const id = parseInt(req.params.id);
  const history = await db
    .select()
    .from(assetHistoryTable)
    .where(eq(assetHistoryTable.assetId, id))
    .orderBy(desc(assetHistoryTable.createdAt));

  res.json(
    history.map((h) => ({
      ...h,
      createdAt: h.createdAt.toISOString(),
    }))
  );
});

router.get("/dashboard/stats", async (req, res) => {
  const assets = await db.select().from(assetsTable);

  const totalAssets = assets.length;
  const assignedAssets = assets.filter((a) => a.status === "ASSIGNED").length;
  const inRepair = assets.filter((a) => a.status === "IN_REPAIR").length;
  const lost = assets.filter((a) => a.status === "LOST").length;
  const writtenOff = assets.filter((a) => a.status === "WRITTEN_OFF").length;
  const registered = assets.filter((a) => a.status === "REGISTERED").length;

  const THREE_YEARS_MS = 3 * 365 * 24 * 60 * 60 * 1000;
  const agingAssets = assets.filter((a) => {
    if (!a.purchaseDate) return false;
    const d = new Date(a.purchaseDate);
    return Date.now() - d.getTime() > THREE_YEARS_MS;
  }).length;

  const categoryCount: Record<string, number> = {};
  const statusCount: Record<string, number> = {};
  const departmentCount: Record<string, number> = {};

  for (const asset of assets) {
    categoryCount[asset.category] = (categoryCount[asset.category] || 0) + 1;
    statusCount[asset.status] = (statusCount[asset.status] || 0) + 1;
    if (asset.department) {
      departmentCount[asset.department] = (departmentCount[asset.department] || 0) + 1;
    }
  }

  const byCategory = Object.entries(categoryCount).map(([category, count]) => ({ category, count }));
  const byStatus = Object.entries(statusCount).map(([status, count]) => ({ status, count }));
  const byDepartment = Object.entries(departmentCount).map(([department, count]) => ({ department, count }));

  const recentHistory = await db
    .select()
    .from(assetHistoryTable)
    .orderBy(desc(assetHistoryTable.createdAt))
    .limit(10);

  res.json({
    totalAssets,
    assignedAssets,
    inRepair,
    lost,
    writtenOff,
    registered,
    agingAssets,
    byCategory,
    byStatus,
    byDepartment,
    recentActivity: recentHistory.map((h) => ({
      ...h,
      createdAt: h.createdAt.toISOString(),
    })),
  });
});

router.get("/users", async (req, res) => {
  const users = await db.select().from(usersTable);
  res.json(users);
});

export default router;
