import { useState } from "react";
import { useParams, Link } from "wouter";
import { ArrowLeft, UserPlus, Undo2, Wrench, Ban, RefreshCcw, Box, CheckCircle2, AlertTriangle, ShieldCheck, QrCode } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useAsset, useAssetHistory, useAssignAsset, useReturnAsset, useChangeAssetStatus, useAddComment } from "@/hooks/use-assets";
import { DEPARTMENTS, BRANCHES } from "@/lib/mock-data";
import { formatDate, formatDateTime } from "@/lib/utils";

export default function AssetDetail() {
  const params = useParams();
  const assetId = parseInt(params.id || "0");
  
  const { data: asset, isLoading: assetLoading } = useAsset(assetId);
  const { data: history, isLoading: historyLoading } = useAssetHistory(assetId);
  
  const assignMutation = useAssignAsset();
  const returnMutation = useReturnAsset();
  const statusMutation = useChangeAssetStatus();
  const commentMutation = useAddComment();

  // Dialog states
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isStatusOpen, setIsStatusOpen] = useState(false);
  const [assignForm, setAssignForm] = useState({ ownerName: "", ownerType: "Employee", department: "", branch: "", reason: "" });
  const [statusForm, setStatusForm] = useState({ status: "", reason: "" });
  const [commentText, setCommentText] = useState("");

  if (assetLoading || !asset) {
    return <div className="p-8 text-center animate-pulse">Loading asset details...</div>;
  }

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'REGISTERED': return 'bg-gray-100 text-gray-700 border-gray-200';
      case 'ASSIGNED': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'IN_REPAIR': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'LOST': return 'bg-red-100 text-red-700 border-red-200';
      case 'WRITTEN_OFF': return 'bg-slate-800 text-slate-100 border-slate-700';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    assignMutation.mutate({
      id: assetId,
      data: { ...assignForm, assignedBy: "Admin User" }
    }, {
      onSuccess: () => setIsAssignOpen(false)
    });
  };

  const handleStatusChange = (e: React.FormEvent) => {
    e.preventDefault();
    statusMutation.mutate({
      id: assetId,
      data: { ...statusForm, changedBy: "Admin User" }
    }, {
      onSuccess: () => setIsStatusOpen(false)
    });
  };

  const handleQuickAction = (status: string) => {
    setStatusForm({ status, reason: "" });
    setIsStatusOpen(true);
  };

  const handleAddComment = () => {
    if (!commentText.trim()) return;
    commentMutation.mutate({
      id: assetId,
      data: { comment: commentText, addedBy: "Admin User" }
    }, {
      onSuccess: () => setCommentText("")
    });
  };

  const isClosed = asset.status === 'WRITTEN_OFF' || asset.status === 'LOST';

  return (
    <div className="space-y-6 pb-12">
      <div className="flex items-center text-sm text-muted-foreground mb-2">
        <Link href="/assets" className="hover:text-primary flex items-center">
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Assets
        </Link>
        <span className="mx-2">/</span>
        <span className="font-medium text-foreground">{asset.serialNumber}</span>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-display font-bold text-foreground">{asset.assetName}</h1>
            <Badge className={`border uppercase text-[10px] font-bold ${getStatusColor(asset.status)}`} variant="outline">
              {asset.status.replace("_", " ")}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-1">{asset.category} • {asset.assetType} • SN: {asset.serialNumber}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {!isClosed && asset.status !== 'ASSIGNED' && asset.status !== 'IN_REPAIR' && (
            <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
              <DialogTrigger asChild>
                <Button className="shadow-sm">
                  <UserPlus className="w-4 h-4 mr-2" /> Assign
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Assign Asset</DialogTitle></DialogHeader>
                <form onSubmit={handleAssign} className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Assign To Name *</Label>
                    <Input required value={assignForm.ownerName} onChange={e=>setAssignForm({...assignForm, ownerName: e.target.value})} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Department</Label>
                      <Select value={assignForm.department} onValueChange={v=>setAssignForm({...assignForm, department: v})}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent>{DEPARTMENTS.map(d=><SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Branch</Label>
                      <Select value={assignForm.branch} onValueChange={v=>setAssignForm({...assignForm, branch: v})}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent>{BRANCHES.map(b=><SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Reason / Notes</Label>
                    <Textarea value={assignForm.reason} onChange={e=>setAssignForm({...assignForm, reason: e.target.value})} />
                  </div>
                  <div className="flex justify-end pt-4"><Button type="submit">Assign Asset</Button></div>
                </form>
              </DialogContent>
            </Dialog>
          )}

          {!isClosed && asset.status === 'ASSIGNED' && (
            <Button variant="outline" onClick={() => {
              if (confirm("Return this asset to inventory?")) {
                returnMutation.mutate({ id: assetId, data: { returnedBy: "Admin User", reason: "Standard return" }});
              }
            }}>
              <Undo2 className="w-4 h-4 mr-2" /> Return
            </Button>
          )}

          {!isClosed && (
            <>
              {asset.status !== 'IN_REPAIR' && (
                <Button variant="secondary" onClick={() => handleQuickAction('IN_REPAIR')}>
                  <Wrench className="w-4 h-4 mr-2" /> Send to Repair
                </Button>
              )}
              {asset.status === 'IN_REPAIR' && (
                <Button variant="secondary" onClick={() => handleQuickAction('REGISTERED')}>
                  <RefreshCcw className="w-4 h-4 mr-2 text-green-600" /> Mark Repaired
                </Button>
              )}
              <Button variant="destructive" onClick={() => handleQuickAction('LOST')}>
                <AlertTriangle className="w-4 h-4 mr-2" /> Mark Lost
              </Button>
              <Button variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={() => handleQuickAction('WRITTEN_OFF')}>
                <Ban className="w-4 h-4 mr-2" /> Write Off
              </Button>
            </>
          )}
        </div>
      </div>

      <Dialog open={isStatusOpen} onOpenChange={setIsStatusOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Change Status</DialogTitle></DialogHeader>
          <form onSubmit={handleStatusChange} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>New Status</Label>
              <Select value={statusForm.status} onValueChange={v=>setStatusForm({...statusForm, status: v})}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="REGISTERED">Registered</SelectItem>
                  <SelectItem value="IN_REPAIR">In Repair</SelectItem>
                  <SelectItem value="LOST">Lost</SelectItem>
                  <SelectItem value="WRITTEN_OFF">Written Off</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Reason *</Label>
              <Textarea required value={statusForm.reason} onChange={e=>setStatusForm({...statusForm, reason: e.target.value})} />
            </div>
            <div className="flex justify-end pt-4"><Button type="submit">Confirm Change</Button></div>
          </form>
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Details */}
        <div className="col-span-1 lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="border-b bg-muted/30 pb-4">
              <CardTitle className="text-lg">Asset Information</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <dl className="divide-y divide-border">
                <div className="grid grid-cols-3 p-4">
                  <dt className="text-sm font-medium text-muted-foreground">Current Owner</dt>
                  <dd className="text-sm col-span-2 font-medium">{asset.ownerName || <span className="italic text-muted-foreground">None</span>}</dd>
                </div>
                <div className="grid grid-cols-3 p-4 bg-muted/10">
                  <dt className="text-sm font-medium text-muted-foreground">Department & Branch</dt>
                  <dd className="text-sm col-span-2">{asset.department || '-'} • {asset.branch || '-'}</dd>
                </div>
                <div className="grid grid-cols-3 p-4">
                  <dt className="text-sm font-medium text-muted-foreground">Purchase Date</dt>
                  <dd className="text-sm col-span-2">{asset.purchaseDate ? formatDate(asset.purchaseDate) : '-'}</dd>
                </div>
                <div className="grid grid-cols-3 p-4 bg-muted/10">
                  <dt className="text-sm font-medium text-muted-foreground">Asset Age</dt>
                  <dd className="text-sm col-span-2">{asset.ageDays ? `${asset.ageDays} days` : '-'}</dd>
                </div>
                <div className="grid grid-cols-3 p-4">
                  <dt className="text-sm font-medium text-muted-foreground">Description</dt>
                  <dd className="text-sm col-span-2">{asset.description || 'No description provided.'}</dd>
                </div>
              </dl>
            </CardContent>
          </Card>

          {/* AI Insights Placeholder */}
          <div>
            <h3 className="text-lg font-bold mb-4 flex items-center">
              <Bot className="w-5 h-5 mr-2 text-primary" />
              AI Insights & Recommendations
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="p-4">
                  <div className="flex items-center mb-2">
                    <ShieldCheck className="w-5 h-5 text-primary mr-2" />
                    <span className="font-semibold text-primary">Audit Recommendation</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Asset is fully compliant with branch security policies. Next audit due in 6 months.</p>
                </CardContent>
              </Card>
              <Card className="bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-900">
                <CardContent className="p-4">
                  <div className="flex items-center mb-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600 mr-2" />
                    <span className="font-semibold text-green-700">Failure Risk Score</span>
                  </div>
                  <p className="text-sm text-muted-foreground">Low Risk (12%). Based on age and repair history, this asset is performing well.</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Comments */}
          <Card>
            <CardHeader className="border-b bg-muted/30 pb-4">
              <CardTitle className="text-lg">Notes & Comments</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex gap-3 mb-6">
                <Textarea 
                  placeholder="Add a note about this asset..." 
                  className="min-h-[80px]"
                  value={commentText}
                  onChange={e=>setCommentText(e.target.value)}
                />
                <Button className="self-end" onClick={handleAddComment} disabled={!commentText.trim() || commentMutation.isPending}>
                  Post Note
                </Button>
              </div>
              
              <div className="space-y-4">
                {history?.filter(h => h.action === "Comment Added").map(comment => (
                  <div key={comment.id} className="bg-muted/40 rounded-lg p-4 text-sm">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-semibold">{comment.changedBy}</span>
                      <span className="text-xs text-muted-foreground">{formatDateTime(comment.createdAt)}</span>
                    </div>
                    <p className="text-foreground/90 whitespace-pre-wrap">{comment.newValue}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* QR Code */}
          <Card className="overflow-hidden">
            <div className="bg-primary p-4 text-primary-foreground text-center">
              <h3 className="font-bold">Asset Tag</h3>
              <p className="text-primary-foreground/80 text-xs mt-1">BankAssetIQ Scannable</p>
            </div>
            <CardContent className="p-6 flex flex-col items-center">
              <div className="p-2 border-2 border-border rounded-xl bg-white mb-4">
                <img src={`${import.meta.env.BASE_URL}images/qr-placeholder.png`} alt="QR Code" className="w-32 h-32 object-contain" />
              </div>
              <p className="font-mono font-bold text-lg tracking-wider">{asset.serialNumber}</p>
              <p className="text-sm text-muted-foreground mt-2 text-center">{asset.branch}</p>
            </CardContent>
          </Card>

          {/* History Timeline */}
          <Card>
            <CardHeader className="pb-4 border-b">
              <CardTitle className="text-lg">Lifecycle History</CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="relative border-l-2 border-border ml-3 mt-2 space-y-6">
                {history?.filter(h => h.action !== "Comment Added").map((entry, i) => (
                  <div key={entry.id} className="relative pl-6">
                    <div className="absolute w-3 h-3 bg-primary rounded-full -left-[7px] top-1.5 ring-4 ring-card"></div>
                    <div className="text-xs text-muted-foreground font-mono mb-1">{formatDate(entry.createdAt)}</div>
                    <div className="font-semibold text-sm">{entry.action}</div>
                    {entry.newValue && <div className="text-sm mt-1 text-foreground/80">{entry.newValue}</div>}
                    {entry.reason && <div className="text-xs mt-1 italic text-muted-foreground">"{entry.reason}"</div>}
                    <div className="text-xs text-muted-foreground mt-1">by {entry.changedBy}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
