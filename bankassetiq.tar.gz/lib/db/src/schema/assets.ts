import { pgTable, serial, text, integer, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const assetStatusEnum = pgEnum("asset_status", [
  "REGISTERED",
  "ASSIGNED",
  "IN_REPAIR",
  "LOST",
  "WRITTEN_OFF",
]);

export const assetCategoryEnum = pgEnum("asset_category", [
  "IT",
  "Office",
  "Security",
  "Networking",
  "Infrastructure",
]);

export const ownerTypeEnum = pgEnum("owner_type", [
  "Employee",
  "Department",
  "Branch",
]);

export const assetsTable = pgTable("assets", {
  id: serial("id").primaryKey(),
  assetName: text("asset_name").notNull(),
  assetType: text("asset_type").notNull(),
  category: assetCategoryEnum("category").notNull(),
  serialNumber: text("serial_number").notNull().unique(),
  description: text("description"),
  status: assetStatusEnum("status").notNull().default("REGISTERED"),
  ownerName: text("owner_name"),
  ownerType: ownerTypeEnum("owner_type"),
  assignedBy: text("assigned_by"),
  assignedDate: text("assigned_date"),
  department: text("department"),
  branch: text("branch"),
  purchaseDate: text("purchase_date"),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const assetHistoryTable = pgTable("asset_history", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").notNull().references(() => assetsTable.id, { onDelete: "cascade" }),
  action: text("action").notNull(),
  oldValue: text("old_value"),
  newValue: text("new_value"),
  changedBy: text("changed_by").notNull(),
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  role: text("role").notNull().default("IT Asset Manager"),
  department: text("department"),
  branch: text("branch"),
});

export const insertAssetSchema = createInsertSchema(assetsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertHistorySchema = createInsertSchema(assetHistoryTable).omit({
  id: true,
  createdAt: true,
});

export type Asset = typeof assetsTable.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type AssetHistory = typeof assetHistoryTable.$inferSelect;
export type User = typeof usersTable.$inferSelect;
