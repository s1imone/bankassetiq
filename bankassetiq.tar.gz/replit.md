# Workspace

## Overview

BankAssetIQ — Smart Banking / Smart Office Asset Management Platform.
pnpm workspace monorepo using TypeScript.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, Tailwind CSS, shadcn/ui, Recharts, Zustand

## BankAssetIQ Product

Enterprise internal asset management platform for banks. Features:
- Login (demo: admin@bank.com / password)
- Dashboard with charts, stat cards, recent activity
- Assets list with search, filters, add/edit/delete
- Asset detail: lifecycle management, assignments, QR code, history timeline, AI placeholders
- Asset statuses: REGISTERED, ASSIGNED, IN_REPAIR, LOST, WRITTEN_OFF
- Asset Assistant chatbot (FAQ-based)
- Roadmap 2.0 page with future features

## Structure

```text
artifacts-monorepo/
├── artifacts/
│   ├── bankassetiq/        # React+Vite frontend (serves at /)
│   └── api-server/         # Express API server (serves at /api)
├── lib/
│   ├── api-spec/           # OpenAPI spec + Orval codegen config
│   ├── api-client-react/   # Generated React Query hooks
│   ├── api-zod/            # Generated Zod schemas from OpenAPI
│   └── db/                 # Drizzle ORM schema + DB connection
├── scripts/                # Utility scripts
├── pnpm-workspace.yaml
├── tsconfig.base.json
├── tsconfig.json
└── package.json
```

## Database Schema

Tables:
- `assets` — main asset table with status enum, owner info, etc.
- `asset_history` — full audit trail for every asset action
- `users` — system users (employees, managers, admins)

## Frontend Architecture

The frontend uses Zustand (`src/lib/mock-data.ts`) for in-memory state management with realistic sample data pre-seeded. All mutations update Zustand state and invalidate React Query cache. The app works fully without needing the backend API.

## API Routes

- `GET /api/assets` — list assets (with filters)
- `POST /api/assets` — create asset
- `GET /api/assets/:id` — get asset detail
- `PUT /api/assets/:id` — update asset
- `DELETE /api/assets/:id` — delete asset
- `POST /api/assets/:id/assign` — assign asset to owner
- `POST /api/assets/:id/status` — change asset status
- `POST /api/assets/:id/return` — return asset
- `POST /api/assets/:id/comments` — add comment
- `GET /api/assets/:id/history` — get asset history
- `GET /api/dashboard/stats` — dashboard statistics
- `GET /api/users` — list users
- `GET /api/healthz` — health check

## Sample Data

10 realistic banking assets pre-seeded:
- Dell Latitude 5440 (IT, ASSIGNED)
- HP LaserJet Pro M404dn (Office, REGISTERED)
- Hikvision DS-2CD2143G2-I (Security, ASSIGNED)
- Cisco Catalyst 2960-X (Networking, IN_REPAIR)
- Lenovo ThinkVision E24-20 (IT, ASSIGNED)
- APC Smart-UPS 1500VA (Infrastructure, REGISTERED)
- ZKTeco SF300 Fingerprint Terminal (Security, ASSIGNED)
- NCR 7606 Bank Teller Terminal (IT, LOST)
- Canon imageCLASS MF644Cdw (Office, ASSIGNED)
- Dell PowerEdge R540 (Infrastructure, WRITTEN_OFF)

## TypeScript & Composite Projects

Every package extends `tsconfig.base.json` which sets `composite: true`. The root `tsconfig.json` lists all lib packages as project references.

## Root Scripts

- `pnpm run build` — runs `typecheck` first, then recursively runs `build` in all packages
- `pnpm run typecheck` — runs `tsc --build --emitDeclarationOnly` using project references
- `pnpm --filter @workspace/api-spec run codegen` — regenerates API client + Zod schemas from OpenAPI
- `pnpm --filter @workspace/db run push` — push schema changes to database
